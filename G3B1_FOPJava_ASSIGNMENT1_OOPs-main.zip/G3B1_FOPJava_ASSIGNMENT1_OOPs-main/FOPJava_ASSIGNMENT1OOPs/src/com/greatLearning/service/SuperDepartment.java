package com.greatLearning.service;

public class SuperDepartment {
	
	public String departmentName() {
		String name = "SuperDepartment" ;
		return name;
	}
	
	public String getTodaysWork() {
		String todaysWork = "No Work as of now";
		return todaysWork;
	}
	
	public String getWorkDeadline() {
		String deadline = "Nil";
		return deadline;
	}
	
	public String isTodayAHoliday() {
		String holiday = "Today is not a holiday";
		return holiday;
	}

}
